package org.example.domain.contas.enums;

public enum TiposContaPJ {
    CONTA_CORRENTE,
    CONTA_SALARIO
}
