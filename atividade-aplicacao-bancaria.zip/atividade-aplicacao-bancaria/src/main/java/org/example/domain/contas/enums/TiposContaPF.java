package org.example.domain.contas.enums;

public enum TiposContaPF {
    CONTA_CORRENTE,
    CONTA_CONJUNTA,
    CONTA_POUPANCA
}
