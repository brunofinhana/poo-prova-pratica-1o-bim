package org.example.domain.pessoas.enums;

public enum EstadoCivil {
    SOLTEIRO,
    CASADO,
    UNIAO_ESTAVEL,
    DIVORCIADO,
    VIUVO
}
