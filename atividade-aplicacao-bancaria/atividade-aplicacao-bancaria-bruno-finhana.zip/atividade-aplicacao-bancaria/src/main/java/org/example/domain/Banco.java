package org.example.domain;

public class Banco {
}
