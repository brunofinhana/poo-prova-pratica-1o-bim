package org.example.domain;

public class ContaCorrente extends Conta {

    public ContaCorrente(Double saldo, Integer agencia, Integer conta) {
        super(saldo, agencia, conta);
    }

}
