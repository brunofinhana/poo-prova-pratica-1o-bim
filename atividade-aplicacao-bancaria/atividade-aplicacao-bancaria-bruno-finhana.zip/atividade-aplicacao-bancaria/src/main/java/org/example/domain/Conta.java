package org.example.domain;

import org.example.exceptions.ContaException;

public abstract class Conta {

    private Double saldo = 0d;
    private Integer agencia;
    private Integer conta;

    // ==============================================================
    // Construtor
    public Conta(Double saldo, Integer agencia, Integer conta) {
        this.saldo = saldo;
        this.agencia = agencia;
        this.conta = conta;
    }

    // ==============================================================
    // Getters e Setters
    public Double getSaldo() {
        return saldo;
    }

    public Integer getAgencia() {
        return agencia;
    }

    public Integer getConta() {
        return conta;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    public void setAgencia(Integer agencia) {
        this.agencia = agencia;
    }

    public void setConta(Integer conta) {
        this.conta = conta;
    }

    // ==============================================================
    // Outros métodos

    // Depósito
    public Double realizarDeposito(Double valor) throws ContaException {
        if(valor > 0) {
            // setSaldo(saldo + valor);
            setSaldo(getSaldo() + valor);
        } else {
            throw new ContaException("Desculpe, não foi possível realizar a transação. Valor de depósito não autorizado.");
            // System.out.println("Desculpe, não foi possível realizar a transação. Valor de depósito não autorizado.");
        }

        return getSaldo();

    }

    // Saque
    public Double realizarSaque(Double valor) {
        if(getSaldo() > 0 && valor >= 0 && valor < getSaldo()) {
            setSaldo(getSaldo() - valor);
        } else {
            System.out.println("Desculpe, não foi possível realizar a transação. Valor de saque não autorizado.");
        }

        return getSaldo();

    }

    // Pagamento
    public Double realizarTransferencia(Double valor, Conta contaDestino) {
        if(getSaldo() <= 0) {
            System.out.println("Saldo insuficiente");
        } else if(valor <= 0) {
            System.out.println("O valor precisa ser maior do que R$0.00");
        } else if(valor > getSaldo()) {
            System.out.println("Saldo insuficiente");
        } else {
            System.out.println("Transação realizada com sucesso!");
            setSaldo(getSaldo() - valor);
            try {
                contaDestino.realizarDeposito(valor);
            } catch (ContaException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        return getSaldo();

    }
}
