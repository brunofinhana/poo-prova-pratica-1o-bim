package org.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.example.domain.ContaCorrente;

public class CCorrenteTest {

    // ==========================================================================
    // DEPÓSITO
    // ==========================================================================

    // Criando um objeto de conta corrente com saldo zerado
    private ContaCorrente ccTesteDeposito;

    @BeforeEach
    void objetoTesteDeposito() {
        ccTesteDeposito = new ContaCorrente(0d,1000,1000);
    }

    // Testando valores positivos
    @Test
    @DisplayName("Depósito positivo R$50")
    void realizarDepositoPositivoTeste() {
        assertEquals(50d, ccTesteDeposito.realizarDeposito(50d));
    }

    @Test
    @DisplayName("Depósito positivo com vírgula R$15.50")
    void realizarDepositoPositivoVirgulaTeste() {
        assertEquals(15.50, ccTesteDeposito.realizarDeposito(15.50));
    }

    // Testando zero
    @Test
    @DisplayName("Depósito R$0.00")
    void realizarDepositoZeroTeste() {
        assertEquals(0d, ccTesteDeposito.realizarDeposito(0d));
    }

    // Testando valores negativos
    @Test
    @DisplayName("Depósito Negativo R$10.00")
    void realizarDepositoNegativoTeste() {
        assertEquals(0d, ccTesteDeposito.realizarDeposito(-10d));
    }

    @Test
    @DisplayName("Depósito Negativo Vírgula R$13.20")
    void realizarDepositoNegativoVirgulaTeste() {
        assertEquals(0d, ccTesteDeposito.realizarDeposito(-13.20));
    }

    // ==========================================================================
    // SAQUE
    // ==========================================================================

    // Criando um objeto de conta corrente com saldo de R$100
    ContaCorrente ccTesteSaque;

    @BeforeEach
    void objetoTesteSaque() {
         ccTesteSaque = new ContaCorrente(100d, 1000, 1000);
        System.out.println(ccTesteSaque.getSaldo());
    }

    // Testando valores positivos
    @Test
    @DisplayName("Saque positivo R$50")
    void realizarSaquePositivoTeste() { assertEquals(50d, ccTesteSaque.realizarSaque(50d)); }

    @Test
    @DisplayName("Saque positivo com vírgula R$15.50")
    void realizarSaquePositivoVirgulaTeste() {
        assertEquals(84.50, ccTesteSaque.realizarSaque(15.50));
    }

    // Testando zero
    @Test
    @DisplayName("Saque R$0.00")
    void realizarSaqueZeroTeste() {
        assertEquals(100d, ccTesteSaque.realizarSaque(0d));
    }

    // Testando valores negativos
    @Test
    @DisplayName("Saque Negativo R$10.00")
    void realizarSaqueNegativoTeste() {
        assertEquals(100d, ccTesteSaque.realizarSaque(-10d));
    }

    @Test
    @DisplayName("Saque Negativo Vírgula R$13.20")
    void realizarSaqueNegativoVirgulaTeste() {
        assertEquals(100d, ccTesteSaque.realizarSaque(-13.20));
    }

    // ==========================================================================
    // TRANSFERÊNCIA
    // ==========================================================================

    // Criando um objeto de conta corrente com saldo de R$150
    ContaCorrente ccTesteTransferenciaOrigem;
    ContaCorrente ccTesteTransferenciaDestino;

    @BeforeEach
    void objetoTesteTransferencia() {
        ccTesteTransferenciaOrigem = new ContaCorrente(150d, 1000, 1000);
        System.out.println(ccTesteTransferenciaOrigem.getSaldo());

        ccTesteTransferenciaDestino = new ContaCorrente(0d, 1000, 1001);
        System.out.println(ccTesteTransferenciaDestino.getSaldo());
    }

    // Testando valores positivos
    @Test
    @DisplayName("Transferência positivo R$50")
    void realizarTransferenciaPositivoTeste() {
        assertEquals(100d, ccTesteTransferenciaOrigem.realizarTransferencia(50d, ccTesteTransferenciaDestino));
        assertEquals(50d, ccTesteTransferenciaDestino.getSaldo());
    }

    @Test
    @DisplayName("Transferência positivo com vírgula R$15.50")
    void realizarTransferenciaPositivoVirgulaTeste() {
        assertEquals(134.5, ccTesteTransferenciaOrigem.realizarTransferencia(15.5, ccTesteTransferenciaDestino));
        assertEquals(15.5, ccTesteTransferenciaDestino.getSaldo());
    }

    // Testando zero
    @Test
    @DisplayName("Transferência R$0.00")
    void realizarTransferenciaZeroTeste() {
        assertEquals(150, ccTesteTransferenciaOrigem.realizarTransferencia(0d, ccTesteTransferenciaDestino));
        assertEquals(0, ccTesteTransferenciaDestino.getSaldo());
    }

    // Testando valores negativos
    @Test
    @DisplayName("Transferência Negativo R$10.00")
    void realizarTransferenciaNegativoTeste() {
        assertEquals(150, ccTesteTransferenciaOrigem.realizarTransferencia(-10d, ccTesteTransferenciaDestino));
        assertEquals(0d, ccTesteTransferenciaDestino.getSaldo());
    }

    @Test
    @DisplayName("Transferência Negativo Vírgula R$13.20")
    void realizarTransferenciaNegativoVirgulaTeste() {
        assertEquals(150d, ccTesteTransferenciaOrigem.realizarTransferencia(-13.2, ccTesteTransferenciaDestino));
        assertEquals(0d, ccTesteTransferenciaDestino.getSaldo());
    }
}