package org.example;

import org.example.domain.ContaCorrente;

public class Main {
    public static void main(String[] args) {

        // DUVIDAS PROFESSOR
        // [] A logica por tras do diagrama esta correta?
        // [] A utilizacao de getters e setters esta correto na classe conta? Essa e a melhor maneira de fazer isso?
        // []

        // CHECK LIST
        // [x] Em todos os métodos, transformar as partes que modificam o saldo utilizando a função setSaldo();
        // [] Introduzir as Exceptions em todos os métodos
        //



    }
}