package org.example.exceptions;

public class ContaException extends Exception {

    // ==========================================================================
    // DEPÓSITO
    // ==========================================================================

    // Valor depositado é <= 0
    public ContaException(String mensagemErro) {
        super(mensagemErro);
    }

    // ==========================================================================
    // SAQUE
    // ==========================================================================

}
